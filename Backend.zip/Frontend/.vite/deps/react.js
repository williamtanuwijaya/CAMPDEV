import {
  require_react
} from "./chunk-L7APZED3.js";
export default require_react();
//# sourceMappingURL=react.js.map
