import tm1 from './../../../assets/images/tm1.jpg'
import tm2 from './../../../assets/images/tm2.jpg'
import tm3 from './../../../assets/images/tm3.jpg'
import tm4 from './../../../assets/images/tm4.jpg'
import tm5 from './../../../assets/images/tm5.jpg'



const data = [
    { id: 1, name: "Dr.Robert", job: 'Fullstack Developer', image: tm1 },
    { id: 2, name: "Duke Alferd Washington", job: 'Back End Developer', image: tm2 },
    { id: 3, name: "Dr.Isaac Newton,M.Si", job: 'Machine Learning Enginner', image: tm3 },
    { id: 4, name: "Prof Einstein M.Sc PhD", job: 'Fullstack Developer', image: tm4 },
    { id: 5, name: "Sir Nikola Tesla", job: 'Engineering', image: tm5 },

]

export default data;