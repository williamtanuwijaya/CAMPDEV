import {
    FaShoppingBag, FaTwitter, FaLinkedin,
    FaFacebook, FaInstagram, FaYoutube, FaMapMarked, FaPhone, FaEnvelope, FaWhatsapp
} from 'react-icons/fa'

const data = [
    { id: 1, title: 'Courses', num: '450+', icon: (FaEnvelope) },
    { id: 2, title: 'Students', num: '99,000', icon: (FaEnvelope) },
    { id: 3, title: 'Awards', num: '100', icon: (FaEnvelope) }


]

export default data;