const data = [
    { id: 1, title: 'Blockchain', explain: 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Illum, qui!' },
    { id: 2, title: 'Graphic Design', explain: 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Illum, qui!' },
    { id: 3, title: 'Finance', explain: 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Illum, qui!' },
    { id: 4, title: 'Marketing', explain: 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Illum, qui!' },
    { id: 5, title: 'Music', explain: 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Illum, qui!' },
    { id: 6, title: 'Business', explain: 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Illum, qui!' }

]
export default data;