import avatar1 from './../../../assets/images/avatar1.jpg';
import avatar2 from './../../../assets/images/avatar2.jpg';
import avatar3 from './../../../assets/images/avatar3.jpg';
import avatar4 from './../../../assets/images/avatar4.jpg';
import avatar5 from './../../../assets/images/avatar5.jpg';

const data = [
    { id: 1, image : {avatar1}},
    { id: 2, image : {avatar2}},
    { id: 3, image : {avatar3}},
    { id: 4, image : {avatar4}},
];

export default data;